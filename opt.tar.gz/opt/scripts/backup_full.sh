#!/bin/bash

# Función para mostrar ayuda
mostrar_ayuda() {
  echo "Uso: $0 <directorio_origen> <directorio_destino>"
  echo "Script para realizar backups de directorios."
  echo "Parámetros:"
  echo "  directorio_origen: Directorio a respaldar."
  echo "  directorio_destino: Directorio donde se guardará el backup."
  echo "Opciones:"
  echo "  -h  Muestra esta ayuda."
  exit 0
}

# Si el usuario pasa la opción -h, mostramos ayuda
if [[ "$1" == "-h" ]]; then
  mostrar_ayuda
fi

# Validamos que el número de argumentos sea correcto
if [[ $# -ne 2 ]]; then
  echo "Error: Se requieren dos parámetros (origen y destino)."
  echo "Use $0 -h para más información."
  exit 1
fi

# Asignar los argumentos a variables
ORIGEN=$1
DESTINO=$2

# Validar que el directorio de origen exista
if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: El directorio origen '$ORIGEN' no existe o no está montado."
  exit 1
fi

# Validar que el directorio de destino exista
if [[ ! -d "$DESTINO" ]]; then
  echo "Error: El directorio destino '$DESTINO' no existe o no está montado."
  exit 1
fi

# Obtener la fecha actual en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Crear el nombre del archivo de backup
NOMBRE_BACKUP="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"

# Ejecutar el comando de backup
echo "Iniciando backup de $ORIGEN a $DESTINO/$NOMBRE_BACKUP..."
tar -czf "$DESTINO/$NOMBRE_BACKUP" -C "$ORIGEN" .

# Verificar si el backup fue exitoso
if [[ $? -eq 0 ]]; then
  echo "Backup completado exitosamente: $DESTINO/$NOMBRE_BACKUP"
else
  echo "Error al realizar el backup."
  exit 1
fi
