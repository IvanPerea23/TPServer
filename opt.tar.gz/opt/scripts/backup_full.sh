#!/bin/bash

# Verificar si los sistemas de archivos de origen y destino están disponibles
if ! mount | grep -q '/backup_dir'; then
  echo "El sistema de archivos de destino no está montado. Abortando el backup."
  exit 1
fi

# Mostrar mensaje de ayuda si el usuario solicita -help
if [ "$1" == "-help" ]; then
  echo "Uso del script backup_full.sh:"
  echo "backup_full.sh <origen> <destino>"
  echo "El origen es el directorio a respaldar (e.g., /var/log)"
  echo "El destino es el directorio donde se almacenará el backup (e.g., /backup_dir)"
  exit 0
fi

# Validar que se pasen los argumentos correctos
if [ $# -lt 2 ]; then
  echo "Uso incorrecto. Se requieren dos argumentos: origen y destino."
  exit 1
fi

ORIGEN=$1
DESTINO=$2

# Verificar si el directorio de origen existe
if [ ! -d "$ORIGEN" ]; then
  echo "El directorio de origen no existe: $ORIGEN"
  exit 1
fi

# Crear el nombre del archivo con la fecha en formato ANSI
FECHA=$(date +%Y%m%d)
NOMBRE_BKP="${DESTINO}/$(basename $ORIGEN)_bkp_${FECHA}.tar.gz"

# Crear el archivo comprimido del backup
tar -czf $NOMBRE_BKP -C $(dirname $ORIGEN) $(basename $ORIGEN)

# Verificar si el backup se realizó correctamente
if [ $? -eq 0 ]; then
  echo "Backup realizado exitosamente: $NOMBRE_BKP"
else
  echo "Error al realizar el backup."
  exit 1
fi

