 poweroff
 poweroff
ls
cls
cls
exit
exit
exit
exit
exit
fdisk -l
fdisk /dev/sdc 
clear
fdisk -l
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
lsblk -f
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
clear
df -h
clear
blkid 
clear
sudo vi /etc/fstab 
sudo vi /etc/fstab 
clear
sudo vi /etc/fstab 
clear
mount -a
df -h
cat /proc/partitions 
cat /proc/partitions > /proc/particion
clear
cat /proc/partitions > /root/particion
caat /root/particion 
cat /root/particion 
shutdown 
shutdown now
clear
sudo apt update
apt list --upgradable 
sudo apt upgrade
clear
sudo apt install git
clear
git config --global user.name "IvanPerea23"
#git config --global user.email 
clear
git config --global user.name "IvanPerea23"
git config --global user.email "ivan9396@hotmail.com"
git config --global --list 
clear
clear
cat /proc/partitions 
cat /root/particion 
clear
sudo mkdir -p /opt/scripts
ip a
clear
ls
cd /opt/scripts/
ls
cd
clea
clear
ls
clear
sudo chmod +x /opt/scripts/backup_full.sh 
clear
git clone https://github.com/IvanPerea23/TPServer.git
cd TPServer/
clear
ls
vi README.md 
clear
git add README.md 
git commit -m "README.md con el nombre del participante"
clear
git status
git log 
git push origin main 
clear
git push origin main 
clear
git log 
git push origin main 
clear
git push origin main 
git remote -v
clear
cd TPServer/
clear
git push 
git config --global credential.helper store
git remote -v
clear
git remote set-url origin https://github.com/IvanPerea23/TPServer.git
clear
ssh-keygen -t rsa -b 4096 -C "ivan9396@hotmail.com"
clear
git push 
git push -u origin master
git push -u origin 
clear
git push -u origin 
cd
clear
shutdown now
